package GestionSistemaNaves;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario <T> implements Inventariable<T>, Iterable<T>{
    List<T> items = new ArrayList<>();

    @Override
    public void agregar(T item) {
        items.add(item);
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        items.remove(indice);
    }

    @Override
    public int tamanio() {
        return items.size();
    }
    
    private void validarIndice(int indice){
        if(indice < 0 || indice >= items.size()){
            throw new IndexOutOfBoundsException("indice invalido");
        }
    }

    @Override
    public Iterator<T> iterator() {
        if(!items.isEmpty() && items.get(0) instanceof Comparable ){
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return (new ArrayList<>(items)).iterator(); //devuelvo un iterador de una copia para que no puedan remover
    }
    
    
    public Iterator<T> iterator(Comparator<? super T> comparator) {
        List<T> aux = new ArrayList<>(items); //copia de mi lista original ENCAPSULAMIENTO 
        aux.sort(comparator);
        return aux.iterator();
    }
    
    private Iterator<T> iteratorNatural(){
        List<T> aux = new ArrayList<>(items); //copia de mi lista original ENCAPSULAMIENTO 
        aux.sort(null);
        return aux.iterator();
    }
    /*
    public void mostrarContenido(){
        mostrarContenido((Comparator<? super T>) Comparator.naturalOrder());
    }
    */


    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        for (T item : items){
            if (criterio.test(item)) {
                listaFiltrada.add(item);
            }
        }
        return listaFiltrada;
    }

    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        
        for(T item : items){
            accion.accept(item);
        }

    }

    @Override
    public void porCadaElemento(Consumidora<? super T> tarea) {
        
        for(T item : items){
            tarea.usar(item);
        }
        
    }

    @Override
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        
        List<T> toReturn = new ArrayList<>();
        for (T item : items){
            toReturn.add(transformacion.apply(item));
        }
        return toReturn;
    }
    
    
    public static <Produto> void guardarEnArchivo(Inventariable<NaveEspacial> almacenable, String path){
        File archivo = new File(path);
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){
            bw.write("id,marca,precio,tipo\n");
            for(NaveEspacial p : almacenable){
                bw.write(p.toCSV()+"\n");
            }
            //System.out.println("se guardo con exito la informacion");
        }catch (IOException ex) {
            System.out.println(ex.getMessage());
            //ex.printStackTrace();
        }
    }


    public static List<NaveEspacial> cargarProductosCSV(String path){
        List<NaveEspacial> toReturn = new ArrayList<>();
        try(BufferedReader br = new BufferedReader(new FileReader(path))){
            String linea;
            br.readLine(); //SALTO LA 1ERA LINEA (porque no lo uso)
            while((linea = br.readLine()) != null){
                if(linea.endsWith("\n")){
                    linea = linea.substring(linea.length(), -1);
                }
                toReturn.add(NaveEspacial.fromCSV(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;  
    }

    











}
    

    
    
    
        
    
    


    

