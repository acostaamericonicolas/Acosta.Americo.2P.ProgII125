package GestionSistemaNaves;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class GestorNaveEspacial {
        
            
    public static <T> List<T> filtrarInventario(Inventariable<T> almacenable, Predicate<? super T> criterio){
        return almacenable.filtrar(criterio);
    }
    
    public static <T> void paraCadaItemAlmacen(Inventariable<T> almacenable, Consumer<? super T> accion){
        almacenable.paraCadaElemento(accion);
    }
    
    public static <T> List<T> mapearAlmacen(Inventariable<T> almacenable, Function<? super T, ? extends T> transformacion){
        return almacenable.transformar(transformacion);
    }
    
    
    
    
     
    
        
}
        
            
        
    

