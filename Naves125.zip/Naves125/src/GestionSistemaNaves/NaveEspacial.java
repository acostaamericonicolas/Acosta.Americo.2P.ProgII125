
package GestionSistemaNaves;

import java.io.Serializable;


public class NaveEspacial implements Comparable<NaveEspacial>, Serializable, ConvertibleACSV{
    private int id;
    private String nombre;
    private int capacidadDeTripulacion;
    private Categoria categoria;

    public NaveEspacial(int id, String nombre,int capacidadDeTripulacion,  Categoria categoria) {
        this.id = id;
        this.nombre = nombre;
        this.capacidadDeTripulacion = capacidadDeTripulacion;
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "NaveEspacial{" + "id=" + id + ", nombre=" + nombre + ", capacidadDeTripulacion=" + capacidadDeTripulacion + ", categoria=" + categoria + '}';
    }

    @Override
    public String toCSV(){
        return  id + "," + nombre + "," + capacidadDeTripulacion + "," + categoria.toString();
    }

    @Override
    public int compareTo(NaveEspacial p) {
        return Integer.compare(id, p.id);
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCapacidadDeTripulacion() {
        return capacidadDeTripulacion;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    

    /*public void aumentarPrecio(double porcentaje){
        //hacer validacion
        precio = precio + precio*porcentaje / 100;
    }*/
    
    @Override
    public boolean equals (Object o){
        if (o == null){
            return false;
        }
        if(o instanceof NaveEspacial p){
            return Integer.compare(id, p.id)== 0;
        }
        if(o instanceof Categoria t){
            return categoria.equals(t);
        }
        return false;
    }

    
    public static NaveEspacial fromCSV(String empleadoCSV){
            String[] values = empleadoCSV.split(",");
            NaveEspacial toReturn = null;
                if(values.length == 4){
                    int id = Integer.parseInt(values[0]);
                    String nombre = values[1];
                    Categoria categoria = Categoria.valueOf(values[2]);
                    int capacidadDeTripulacion = Integer.parseInt(values[3]);
                    toReturn = new NaveEspacial(id, nombre, capacidadDeTripulacion, categoria);
                }
                return toReturn;
    }
    

    

    

    
}
