
package GestionSistemaNaves;


public enum Categoria {
    CIENTIFICA,
    TRANSPORTE, 
    MILITAR
    }

    
