package GestionSistemaNaves;

public class ComparadorTripulacion implements Comparable<NaveEspacial>{
    /*
    Ordenar elementos: se debe poder ordenar por orden natural o utilizando un Comparator. 
    Por ejemplo, un comparador por capacidad de tripulación.
    */
    @Override
    public int compareTo(NaveEspacial o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
