package GestionSistemaNaves;

public interface ConvertibleACSV {
    String toCSV();
}
