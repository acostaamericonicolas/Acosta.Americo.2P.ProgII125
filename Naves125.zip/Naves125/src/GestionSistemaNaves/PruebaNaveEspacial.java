
package GestionSistemaNaves;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class PruebaNaveEspacial {

   
    public static void main(String[] args) {
        Inventario<NaveEspacial> inventarioNaves = new Inventario<>(); 
        inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", 50, Categoria.CIENTIFICA)); 
        inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", 3, Categoria.TRANSPORTE)); 
        inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", 1, Categoria.MILITAR)); 
        inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", 2, Categoria.MILITAR)); 
        inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", 100, Categoria.CIENTIFICA));
        
        
        System.out.println(" muestro almacen antes de eliminar");
        inventarioNaves.forEach(System.out::println);
        System.out.println("------------------");
        System.out.println(inventarioNaves.obtener(1));
        System.out.println("------------------");
        inventarioNaves.eliminar(1); //ELIMINO EL PRODUCTO 
        System.out.println("elime el producto en el indice 2 ");
        inventarioNaves.forEach(System.out::println);
        System.out.println("------------------");
        System.out.println("el tamanio de ALMACEN es: " + inventarioNaves.tamanio());
        
        separador();
              
        List<NaveEspacial> productosFiltradosTipo = GestorNaveEspacial.
                filtrarInventario(inventarioNaves, nave -> nave.getCategoria().equals(Categoria.CIENTIFICA));
        productosFiltradosTipo.forEach(System.out::println);
        
        separador();
        
        System.out.println("\nNaves cuyo nombre contiene 'Falcon':");
        List<NaveEspacial> productosFiltradosNombre = GestorNaveEspacial.
                filtrarInventario(inventarioNaves, nave -> nave.getNombre().equals("Falcon"));
        productosFiltradosNombre.forEach(System.out::println);
        
        separador();
        
        // Ordenar naves de manera natural (por id) System.out.println("\nNaves ordenadas de manera natural (por id):");
        //inventarioNaves.ordenar();
        
        
        
        // Guardar el inventario en un archivo CSV 
        //GestorNaveEspacial.inventarioNaves.guardarEnArchivo("src/data/naves.csv");
        // Cargar el inventario desde el archivo CSV inventarioCargado.cargarDesdeCSV("src/data/naves.csv", /* Acá va una expresion lambda*/); System.out.println("\nNaves cargadas desde archivo CSV:");
        
        
        
        


        
    }
    
    public static void separador(){
        System.out.println("--------------------------------------");
    }


    

    
    
    
    
    
    
    
}
