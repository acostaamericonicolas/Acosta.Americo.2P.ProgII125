package GestionSistemaNaves;


public interface Consumidora<T>{
    void usar(T o);
    
}
